import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Animation(),
    );
  }
}

class Animation extends StatefulWidget {
  const Animation({super.key});

  @override
  State<Animation> createState() => _AnimationState();
}

class _AnimationState extends State<Animation> {
  List left = [1, 2, 3, 4, 5, 6];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 63, 0, 236),
      body: Container(
        padding: EdgeInsets.only(top: 100, right: 50, left: 50),
        child: Column(
          children: [
            // Padding(
            //   padding: const EdgeInsets.only(left: 20,right: 20),
            //   child: Row(
            //     children: [
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //       SizedBox(width: 7,),
            //       circal(color: Colors.transparent),
            //     ],
            //   ),
            // ),
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height / 3,
                      width: 25,
                      child: ListView.separated(
                          itemBuilder: (context, index) {
                            for (int i = 6; i <= 1; i--) {
                              index++;
                            }
                            return (index == 5)
                                ? circal(color: Colors.red)
                                : (index == 4)
                                    ? circal(color: Colors.green)
                                    : (index == 3)
                                        ? circal(color: Colors.blue)
                                        : circal(color: Colors.transparent);
                          },
                          separatorBuilder: (context, index) {
                            return SizedBox(
                              height: 7,
                            );
                          },
                          itemCount: left.length),
                    ),
                  ],
                ),
                Spacer(),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      height: MediaQuery.of(context).size.height / 3,
                      width: 25,
                      child: ListView.separated(
                          itemBuilder: (context, index) {
                            return circal(color: Colors.transparent);
                          },
                          separatorBuilder: (context, index) {
                            return SizedBox(
                              height: 7,
                            );
                          },
                          itemCount: left.length),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

Container circal({Color? color}) {
  return Container(
    height: 25,
    width: 25,
    decoration: BoxDecoration(
      color: color,
      shape: BoxShape.circle,
      border: Border.all(
        color: Colors.white,
        width: 1,
      ),
    ),
  );
}
